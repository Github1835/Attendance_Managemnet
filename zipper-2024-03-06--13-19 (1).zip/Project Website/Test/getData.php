<?php

include('../db_connect.php');

// Query database
$query = "SELECT * FROM admin";
$cmd = mysqli_query($con,$query);

// Fetch data
$data = array();
if ($result->num_rows > 0) {
    while($row = mysqli_fetch_array($cmd)) {
        $data[] = array(
            'Admin_ID' => $row['Admin_ID'],
            'AdminName' => $row['AdminName'],
            'Email_ID' => $row['Email_ID']
        );
    }
}

// Return data as JSON
echo json_encode($data);
?>
