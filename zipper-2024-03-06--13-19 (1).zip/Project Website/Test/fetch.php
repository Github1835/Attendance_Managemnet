<!DOCTYPE html>
<html>
<head>
	<title>AJAX Example</title>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<script>
		$(document).ready(function(){
			$("#btnGetData").click(function(){
				$.ajax({
					url: "getData.php",
					type: "POST",
					dataType: "json",
					success: function(data){
                        var text = '';
                        for(var i=0; i<data.length; i++) {
                            text += data[i].Admin_ID + ' - ' + data[i].AdminName + ' - ' + data[i].Email_ID + '\n';
                        }
                        $("#txtData").val(text);
                    }
				});
			});
		});
	</script>
</head>
<body>
	<h1>AJAX Example</h1>
	<input type="text" id="txtData"><br><br>
	<input type="text" id="txtData2"><br><br>
	<input type="text" id="txtData3"><br><br>
	<button id="btnGetData">Get Data</button>
</body>
</html>
