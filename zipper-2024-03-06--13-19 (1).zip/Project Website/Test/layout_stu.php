<?php
    session_start();
    $con=mysqli_connect("localhost","id20364318_krish3535","PD1D{Wlw{AOlx6<1")or die("Could not connect");
$db=mysqli_select_db($con,"id20364318_attendancems");
if(isset($db))
{}
?>
<html>
    <head>
        <title>Bootstrap Collapse</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <script defer src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="containerdemo.css">
        <style>
            *{
                margin: 0;
                padding: 0;
            }
        </style>
    </head>
    <body>
        <div class="id"></div>
        <div class="card">
            <div class="card-header text-center bg-dark text-light"><h2>Student(Operation)</h2></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-1">
                        <a href="../Admin/php/Dashboard.php" class="btn btn-primary">Back</a><br><br>
                    </div>
                    <div class="col-11">
                        <button class="btn btn-outline-primary border-2" data-bs-toggle="modal" data-bs-target="#addStu" style="border-radius: 15px; float: right;">+</button>
                    </div>
                </div>
                <div class="alert alert-danger alert-dismissible border-danger">
                    note: You can use Back button to go back to Dashboard
                    <button class="btn btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php
                    if($_SERVER["REQUEST_METHOD"] == "POST"&&$_POST['action']=="Add")
                    {
                        $srollno=$_POST['StuRollno'];
                        $sname=$_POST['StuName'];
                        $gender=$_POST['Gender'];
                        $email=$_POST['Email_ID'];
                        $cno=$_POST['Contact_no'];
                        $sem=$_POST['Sem'];
                        $year=$_POST['Year'];
                        $branch=$_POST['Branch_ID'];
                        

                        $check=addStu($srollno,$sname,$gender,$email,$cno,$sem,$year,$branch);

                        if($check==true)
                        {
                        ?>
                        <div class="alert alert-success alert-dismissible border-danger">
                            New Student has been Added.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php
                        }else
                        {
                            
                        ?>
                        <div class="alert alert-danger alert-dismissible border-danger">
                            Error occured during process OR Record is already available, Plese Try Again.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php 
                        }
                    }
                    if($_SERVER["REQUEST_METHOD"] == "POST"&&$_POST['action']=="Remove")
                    {
                        $srollno=$_POST['StuRollno'];
                        
                        $check=removeStu($srollno);
                        
                        if($check==true)
                        {
                            ?>
                        <div class="alert alert-success alert-dismissible border-danger">
                            Student has been removed.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php
                        }else
                        {
                        ?>
                        <div class="alert alert-danger alert-dismissible border-danger">
                            Error occured during process, Plese Try Again.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php 
                        }
                    }
                    if($_SERVER["REQUEST_METHOD"] == "POST"&&$_POST['action']=="Update")
                    {
                        $srollno=$_POST['StuRollno'];
                        $sname=$_POST['StuName'];
                        $gender=$_POST['Gender'];
                        $email=$_POST['Email_ID'];
                        $cno=$_POST['Contact_no'];
                        $sem=$_POST['Sem'];
                        $year=$_POST['Year'];
                        $branch=$_POST['Branch_ID'];

                        
                        
                        $check=updateStu($srollno,$sname,$gender,$email,$cno,$sem,$year,$branch);
                        
                        if($check==true)
                        {
                            ?>
                        <div class="alert alert-success alert-dismissible border-danger">
                            Student has been Updated.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php
                        }else
                        {
                        ?>
                        <div class="alert alert-danger alert-dismissible border-danger">
                            Error occured during process, Plese Try Again.
                            <button class="btn btn-close" data-bs-dismiss="alert"></button>
                        </div>
                        <?php 
                        }
                    }
                ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Rollno</th>
                                <th>Name</th>
                                <th>Gender</th>
                                <th>E-mail</th>
                                <th>Password</th>
                                <th>Contact no</th>
                                <th>Sem</th>
                                <th>Year</th>
                            </tr>
                        </thead>
                        <?php
                        // include('Project Website/db_connect.php');
                       include('../db_connect.php');
                        $query="select *from student";
                        $cmd=mysqli_query($con,$query);

                        while($row=mysqli_fetch_array($cmd))
                        {
                        ?>
                        <tr>
                            <td><div class="navbar-light">
                                <div class="container">
                                    <button class="navbar-toggler navbar-toggler-icon" data-bs-toggle="collapse" data-bs-target="#s<?php echo $row['StuRollno'];?>"></button>
                                </div>
                            </div></td>
                            <td><p><?php echo $row['StuRollno']; ?></p><a href="UpdateStu.php?StuRollno=<?php echo $row['StuRollno']; ?>" class="btn bg-secondary text-light collapse fade px-3" id="s<?php echo $row['StuRollno'];?>">Update</a></td>
                            <td><p><?php echo $row['StuName']; ?></p><button class="btn bg-secondary text-light collapse fade px-3" id="s<?php echo $row['StuRollno'];?>" data-bs-toggle="modal" data-bs-target="#RemoveStu" onclick="replyR_clicked(this.id)">Remove</button></td>
                            <td><?php echo $row['Gender']; ?></td>
                            <td><?php echo $row['Email_ID']; ?></td>
                            <td><?php echo $row['Password']; ?></td>
                            <td><?php echo $row['Contact_no']; ?></td>
                            <td><?php echo $row['Sem']; ?></td>
                            <td><?php echo $row['Year']; ?></td>
                            
                            
                        </tr>
                        <?php
                        }
                        ?>
                    </table>
                </div>
                
                <div class="modal fade" id="addStu">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="card">
                                    <div class="card-header text-center bg-success text-white">
                                        <h3>Add Student</h3>
                                    </div>
                                    <div class="card-body">
                                        <form action="layout_stu.php" method="POST" novalidate>
                                            <div class="row row-cols-1 g-3">
                                                <div class="col">
                                                    <div class="form-floating">
                                                        <input type="text" id="StuRollno" name="StuRollno" class="form-control" placeholder="Rollno" required>
                                                        <label for="StuRollno" class="form-label">Rollno: </label>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-floating">
                                                        <input type="text" id="StuName" name="StuName" class="form-control" placeholder="Name" required>
                                                        <label for="StuName" class="form-label">Name: </label>
                                                    </div>
                                                </div>
                                                 <div class="col">
                                                    <div class="form-floating">
                                                        <input type="text" id="Gender" name="Gender" class="form-control" placeholder="Gender" required>
                                                        <label for="Gender" class="form-label">Gender: </label>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-floating">
                                                        <input type="email" id="Email_ID" name="Email_ID" class="form-control" placeholder="Name" required>
                                                        <label for="Email_iD" class="form-label">E-mail: </label>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-floating">
                                                        <input type="number" id="Contact_no" name="Contact_no" class="form-control" placeholder="Name" pattern=".{7,}" required>
                                                        <label for="Contact_no" class="form-label">Contact Number: </label>
                                                    </div>
                                                </div>
                                                 <div class="col">
                                                    <div class="form-floating">
                                                        <input type="number" id="Sem" name="Sem" class="form-control" placeholder="Sem" required>
                                                        <label for="Sem" class="form-label">Semester: </label>
                                                    </div>
                                                </div>
                                                 <div class="col">
                                                    <div class="form-floating">
                                                        <input type="number" id="Year" name="Year" class="form-control" placeholder="Year" required>
                                                        <label for="Year" class="form-label">Year: </label>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <select class="form-control mb-2" name="Branch_ID">
                                                        <?php
                                                            include('../db_connect.php');
                                                            $query="select *from branch";
                                                            $cmd=mysqli_query($con,$query);
                                                            
                                                            while($row=mysqli_fetch_array($cmd))
                                                            {
                                                        ?>
                                                        <option value="<?php echo $row['Branch_ID'];?>" class="form-control"><?php echo $row['BranchName'];?></option>
                                                        <?php
                                                            }
                                                        ?>
                                                    </select>
                                                </div>
                                                </div>
                                                <div class="col">
                                                    <button class="btn btn-danger" style="float: left; width: 40%;" data-bs-dismiss="modal" name="action">Close</button>
                                                    <button class="btn btn-success" style="float: right; width: 40%;" name="action" value="Add" id="AddStu">Add</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="RemoveStu">
                    <div class="modal-dialog modal-dialog-scrollable">
                        <div class="modal-content">
                            <div class="modal-body">
                                <div class="card">
                                    <div class="card-header text-center bg-danger text-white">
                                        <h3>Confirm !!</h3>
                                    </div>
                                    <div class="card-body">
                                        <form action="layout_stu.php" method="POST" novalidate>
                                            <div class="row row-cols-1 g-3">
                                                <div class="col">
                                                    <div class="form-floating">
                                                        <input type="text" id="RStuRollno" name="StuRollno" class="form-control" placeholder="Name" readonly>
                                                        <label for="RStuRollno" class="form-label">Rollno: </label>
                                                    </div>
                                                </div>
                                                <div class="col">
                                                    <button class="btn btn-success" style="float: left; width: 40%;" data-bs-dismiss="modal"name="action">Close</button>
                                                    <button class="btn btn-danger" style="float: right; width: 40%;" name="action" value="Remove" id="RemoveStu">Remove</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="card-footer text-center">
                <a href="#top" class="btn btn-secondary" style="width: 30%;">^</a>
            </div>
        </div>
    </body>
</html>
<?php
function addStu($srollno,$sname,$gender,$email,$cno,$sem,$year,$branch)
{
    include('../db_connect.php');
    $srollno=trim($srollno,'s');
    $query="insert into student values('$srollno','$sname','$gender','$email','$cno',$sem,$year,null,'$branch')";
    if(mysqli_query($con,$query))
    return true;
    else
    return false;
}
function removeStu($srollno)
{
   include('../db_connect.php');
       $srollno=trim($srollno,'s');
    $query="delete from student where StuRollno='$srollno'";
    if(mysqli_query($con,$query))
    return true;
    else
    return false;
}
function updateStu($srollno,$sname,$gender,$email,$cno,$sem,$year,$branch)
{
   include('../db_connect.php');
       $srollno=trim($srollno,'s');
    $query="update student set StuName='$sname',Gender='$gender',Email_ID='$email',Contact_no='$cno',Sem=$sem,Year=$year,Branch_ID='$branch' where StuRollno='$srollno'";
    if(mysqli_query($con,$query))
    return true;
    else
    return false;
}
?>
<script> 
    const form = document.querySelector("form")
    form.addEventListener('submit',e=> {
        if(!form.checkValidity()){
            e.preventDefault()
        }
        form.classList.add('was-validated')
    })
    
    function replyR_clicked(clicked_id)
    {
        document.getElementById("RStuRollno").value=clicked_id;
    }
    function replyU_clicked(clicked_id)
    {
        document.getElementById("UStuRollno").value=clicked_id;
    }
</script>