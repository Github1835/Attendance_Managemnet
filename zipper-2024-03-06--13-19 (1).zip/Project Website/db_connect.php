<?php
$con=mysqli_connect("localhost","id20364318_krish3535","PD1D{Wlw{AOlx6<1")or die("Could not connect");
$db=mysqli_select_db($con,"id20364318_attendancems");
if(isset($db))
{}
?>